import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/error/error_handler.dart';
import '../../../../core/usecase/usecase.dart';
import '../entities/standings.dart';
import '../repositories/soccer_repository.dart';

/// Represents the standings use case entity/model.
class StandingsUseCase extends UseCase<Standings, StandingsParams> {
  final SoccerRepository soccerRepository;

  StandingsUseCase({required this.soccerRepository});

  /// Call.
  @override
  Future<Either<Failure, Standings>> call(StandingsParams params) async {
    return await soccerRepository.getStandings(params: params);
  }
}

/// Represents the standings params entity/model.
class StandingsParams extends Equatable {
  final int leagueId;

  const StandingsParams({required this.leagueId});

  @override
  List<Object?> get props => [leagueId];

  Map<String, dynamic> toJson() => {
    'competitions': leagueId,
    'withSeasonsFilter': 'false',
  };
}
